# ✅ Secure DevOps Checklist

Checklist simples e prático de segurança para aplicações em ambientes DevOps. Ideal para equipes que desejam integrar segurança desde o início do ciclo de vida do software (DevSecOps).

## 📦 Estrutura do Projeto
- `checklist.md`: Lista comentada de boas práticas.
- `pipeline-example.yml`: Exemplo básico de pipeline CI/CD com checagens de segurança.
- `scripts/security-scan.sh`: Script simples para escanear vulnerabilidades com ferramentas open-source.

## ✅ Exemplo de Boas Práticas
- [x] Usar análise de dependências (ex: `npm audit`, `pip-audit`)
- [x] Ativar secret scanning no GitHub
- [x] Configurar CI/CD para rodar testes de segurança automatizados
- [x] Utilizar autenticação de dois fatores (2FA)
- [x] Atualizar imagens de containers frequentemente

## 🚀 Como usar
```bash
bash scripts/security-scan.sh
```

## 🔐 Exemplo de pipeline (GitHub Actions)
```yaml
name: CI-Security

on: [push, pull_request]

jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run npm audit
        run: npm audit --audit-level=high
```

## 🧠 Referências
- OWASP DevSecOps Guide
- DevSecOps.org
- GitHub Security Best Practices

---
