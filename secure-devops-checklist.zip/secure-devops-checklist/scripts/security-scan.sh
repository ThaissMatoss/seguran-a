#!/bin/bash

echo "🔍 Rodando verificação de dependências..."
npm audit --audit-level=high

echo "🔐 Procurando segredos no código..."
trufflehog filesystem . --json

echo "✅ Verificação concluída!"
